part of 'welcome_bloc.dart';

abstract class WelcomeEvent {}

class LoginPressed extends WelcomeEvent {}

class SignupPressed extends WelcomeEvent {}
